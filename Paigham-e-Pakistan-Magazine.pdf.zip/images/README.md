Place the provided logo image in this folder and name it `paigham-logo.png`.

- Primary logo: `images/paigham-logo.png` — used in header (recommended @120px height).
- Dark variant: `images/paigham-logo-dark.png` — use this for footer or any dark background to ensure visibility.
- Favicon options:
  - `images/favicon.svg` — an SVG favicon that references `paigham-logo.png` (already added). Modern browsers will use this and it preserves sharpness at any DPI.
  - `images/favicon.png` — 32×32 PNG fallback (recommended to export from the main logo for legacy support).

If you want, I can generate a 32×32 PNG and an ICO file for you (I can create placeholders if you want me to generate them now).