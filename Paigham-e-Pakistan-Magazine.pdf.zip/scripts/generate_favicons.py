"""
Generate favicon.png (32x32) and favicon.ico (16x16 & 32x32) from the source logo.
Requires Pillow: pip install pillow
Run: python scripts/generate_favicons.py
"""
from PIL import Image
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / 'images' / 'paigham-logo.png'
OUT_PNG = Path(__file__).resolve().parent.parent / 'images' / 'favicon.png'
OUT_ICO = Path(__file__).resolve().parent.parent / 'images' / 'favicon.ico'

if not SRC.exists():
    raise SystemExit(f"Source logo not found at {SRC}. Please add 'images/paigham-logo.png' and try again.")

print('Opening source:', SRC)
img = Image.open(SRC).convert('RGBA')

# Create 32x32 PNG (square crop centered)
size_png = (32, 32)
img_png = img.copy()
img_png.thumbnail(size_png, Image.LANCZOS)

# If not square, paste into transparent square
if img_png.size != size_png:
    square = Image.new('RGBA', size_png, (255,255,255,0))
    x = (size_png[0] - img_png.size[0]) // 2
    y = (size_png[1] - img_png.size[1]) // 2
    square.paste(img_png, (x, y), img_png)
    img_png = square

img_png.save(OUT_PNG, format='PNG')
print('Saved PNG favicon:', OUT_PNG)

# Create ICO including 16x16 and 32x32
sizes = [(16,16), (32,32)]
icons = []
for s in sizes:
    temp = img.copy()
    temp.thumbnail(s, Image.LANCZOS)
    if temp.size != s:
        sq = Image.new('RGBA', s, (255,255,255,0))
        x = (s[0] - temp.size[0]) // 2
        y = (s[1] - temp.size[1]) // 2
        sq.paste(temp, (x, y), temp)
        temp = sq
    icons.append(temp)

# PIL accepts a single image and "sizes" param to save ICO
icons[0].save(OUT_ICO, format='ICO', sizes=sizes)
print('Saved ICO favicon:', OUT_ICO)