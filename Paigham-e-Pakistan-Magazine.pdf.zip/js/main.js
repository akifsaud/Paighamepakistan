/* =====================================================
   PAIGHAM-E-PAKISTAN - Main JavaScript
   ===================================================== */

document.addEventListener('DOMContentLoaded', () => {
    initMobileNav();
    initStickyHeader();
    initBackToTop();
    initScrollAnimations();
    initFAQAccordion();
    initTabs();
    initContactForm();
    initCounterAnimation();
});

/* =====================================================
   MOBILE NAVIGATION
   ===================================================== */
function initMobileNav() {
    const toggle = document.querySelector('.nav-toggle');
    const menu = document.querySelector('.nav-menu');
    const overlay = document.querySelector('.nav-overlay');

    if (!toggle || !menu) return;

    // Toggle menu
    toggle.addEventListener('click', () => {
        toggle.classList.toggle('active');
        menu.classList.toggle('active');
        if (overlay) overlay.classList.toggle('active');
        document.body.style.overflow = menu.classList.contains('active') ? 'hidden' : '';
    });

    // Close menu on overlay click
    if (overlay) {
        overlay.addEventListener('click', closeNav);
    }

    // Mobile dropdown toggles
    const dropdownParents = document.querySelectorAll('.nav-item.has-dropdown');
    dropdownParents.forEach(item => {
        const link = item.querySelector('.nav-link');
        link.addEventListener('click', (e) => {
            if (window.innerWidth <= 991) {
                e.preventDefault();
                item.classList.toggle('dropdown-open');
                // Close other dropdowns
                dropdownParents.forEach(other => {
                    if (other !== item) other.classList.remove('dropdown-open');
                });
            }
        });
    });

    // Close nav on dropdown link click (mobile)
    const dropdownLinks = document.querySelectorAll('.dropdown-item');
    dropdownLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 991) {
                closeNav();
            }
        });
    });

    function closeNav() {
        toggle.classList.remove('active');
        menu.classList.remove('active');
        if (overlay) overlay.classList.remove('active');
        document.body.style.overflow = '';
        dropdownParents.forEach(item => item.classList.remove('dropdown-open'));
    }

    // Close menu on resize if larger than mobile
    window.addEventListener('resize', () => {
        if (window.innerWidth > 991) {
            closeNav();
        }
    });
}

/* =====================================================
   STICKY HEADER
   ===================================================== */
function initStickyHeader() {
    const header = document.querySelector('.header');
    if (!header) return;

    let lastScroll = 0;

    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;

        if (currentScroll > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }

        lastScroll = currentScroll;
    }, { passive: true });
}

/* =====================================================
   BACK TO TOP
   ===================================================== */
function initBackToTop() {
    const btn = document.querySelector('.back-to-top');
    if (!btn) return;

    window.addEventListener('scroll', () => {
        if (window.pageYOffset > 400) {
            btn.classList.add('visible');
        } else {
            btn.classList.remove('visible');
        }
    }, { passive: true });

    btn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
}

/* =====================================================
   SCROLL ANIMATIONS
   ===================================================== */
function initScrollAnimations() {
    const elements = document.querySelectorAll('.fade-in, .fade-in-left, .fade-in-right');
    if (!elements.length) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });

    elements.forEach(el => observer.observe(el));
}

/* =====================================================
   FAQ ACCORDION
   ===================================================== */
function initFAQAccordion() {
    const faqItems = document.querySelectorAll('.faq-item');
    if (!faqItems.length) return;

    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        if (!question) return;

        question.addEventListener('click', () => {
            const isActive = item.classList.contains('active');

            // Close all
            faqItems.forEach(other => other.classList.remove('active'));

            // Open clicked if it was closed
            if (!isActive) {
                item.classList.add('active');
            }
        });
    });
}

/* =====================================================
   TABS
   ===================================================== */
function initTabs() {
    const tabContainers = document.querySelectorAll('[data-tabs]');
    if (!tabContainers.length) return;

    tabContainers.forEach(container => {
        const buttons = container.querySelectorAll('.tab-btn');
        const panels = container.querySelectorAll('.tab-panel');

        buttons.forEach(btn => {
            btn.addEventListener('click', () => {
                const target = btn.dataset.tab;

                // Deactivate all
                buttons.forEach(b => b.classList.remove('active'));
                panels.forEach(p => p.classList.remove('active'));

                // Activate clicked
                btn.classList.add('active');
                const panel = container.querySelector(`[data-panel="${target}"]`);
                if (panel) panel.classList.add('active');
            });
        });
    });
}

/* =====================================================
   CONTACT FORM
   ===================================================== */
function initContactForm() {
    const form = document.getElementById('contactForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const data = Object.fromEntries(formData);

        // Validate
        if (!data.name || !data.email || !data.message) {
            showNotification('Please fill in all required fields.', 'error');
            return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(data.email)) {
            showNotification('Please enter a valid email address.', 'error');
            return;
        }

        const btn = form.querySelector('button[type="submit"]');
        const originalText = btn.innerHTML;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
        btn.disabled = true;

        // Simulate submission
        try {
            await new Promise(resolve => setTimeout(resolve, 1500));
            await fetch(`tables/contact_submissions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: data.name,
                    email: data.email,
                    subject: data.subject || '',
                    message: data.message,
                    submitted_at: new Date().toISOString()
                })
            }).catch(() => {}); // Silently fail if table doesn't exist

            form.reset();
            showNotification('Thank you for your message! We will respond shortly.', 'success');
        } catch (err) {
            showNotification('Something went wrong. Please try again.', 'error');
        } finally {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
    });
}

/* =====================================================
   COUNTER ANIMATION
   ===================================================== */
function initCounterAnimation() {
    const counters = document.querySelectorAll('[data-count]');
    if (!counters.length) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const el = entry.target;
                const target = parseInt(el.dataset.count);
                const suffix = el.dataset.suffix || '';
                const prefix = el.dataset.prefix || '';
                animateValue(el, 0, target, 2000, prefix, suffix);
                observer.unobserve(el);
            }
        });
    }, { threshold: 0.3 });

    counters.forEach(counter => observer.observe(counter));
}

function animateValue(el, start, end, duration, prefix, suffix) {
    const range = end - start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));
    const minStep = 16;
    const actualStep = Math.max(stepTime, minStep);
    const valueIncrement = Math.ceil(range / (duration / actualStep));

    let current = start;
    const timer = setInterval(() => {
        current += valueIncrement;
        if ((increment > 0 && current >= end) || (increment < 0 && current <= end)) {
            current = end;
            clearInterval(timer);
        }
        el.textContent = prefix + current.toLocaleString() + suffix;
    }, actualStep);
}

/* =====================================================
   NOTIFICATIONS
   ===================================================== */
function showNotification(message, type = 'info') {
    // Remove existing
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;

    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        info: 'fa-info-circle',
        warning: 'fa-exclamation-triangle'
    };

    notification.innerHTML = `
        <i class="fas ${icons[type] || icons.info}"></i>
        <span>${message}</span>
        <button class="notification-close" aria-label="Close">
            <i class="fas fa-times"></i>
        </button>
    `;

    document.body.appendChild(notification);

    // Show
    requestAnimationFrame(() => {
        notification.classList.add('show');
    });

    // Auto remove
    const autoRemove = setTimeout(() => removeNotification(notification), 5000);

    notification.querySelector('.notification-close').addEventListener('click', () => {
        clearTimeout(autoRemove);
        removeNotification(notification);
    });
}

function removeNotification(notification) {
    notification.classList.remove('show');
    setTimeout(() => notification.remove(), 300);
}

/* =====================================================
   ACTIVE NAV HIGHLIGHTING
   ===================================================== */
// Highlight current page in navigation
(function highlightCurrentPage() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    const navLinks = document.querySelectorAll('.nav-link');

    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage || (currentPage === 'index.html' && href === 'index.html')) {
            link.classList.add('active');
        }
    });
})();
